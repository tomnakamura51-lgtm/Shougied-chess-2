Shogied Chess Browser版

1. ZIPを展開
2. index.html をブラウザで開く
3. 盤面の駒をタップ
4. 緑の移動先／赤の攻撃先をタップ

スマートフォンではファイルアプリ等から index.html をブラウザで開いてください。
